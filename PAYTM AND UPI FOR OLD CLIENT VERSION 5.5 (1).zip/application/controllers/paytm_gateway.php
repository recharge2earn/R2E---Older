<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paytm_gateway extends CI_Controller {
	
	
	private $msg='';
	public function pageview()
	{
	
		$this->view_data['message'] =$this->msg;
		$this->load->view('paytm_gateway_view',$this->view_data);		
	}
	
	public function index() 
	{
	    
	   
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
$this->output->set_header("Pragma: no-cache"); 

		if ($this->session->userdata('logged_in') != TRUE) 
		{ 
			redirect(base_url().'login'); 
		}
	
		else 
		{ 
			$data['message']='';				
			if($this->input->post("btnSubmit") == 'Submit')
			{								
				$request_amount = $this->input->post("txtReqamt",TRUE);
						
				$user_id =$this->session->userdata("id");	
				
				if($request_amount > 50000 or $request_amount < 200 )
				
				{
				    
			$this->session->set_flashdata('message', 'Minimum 200 and maximum 50000 allowed');
					redirect(base_url()."paytm_gateway");exit;
				}
						
				
				redirect(base_url()."/pay?CUST_ID=".$user_id."&TXN_AMOUNT=".$request_amount);
			
				 
				 
				 
				 
			
				 
				
	
		
		
			
	
			}			
			else
			{
				$user=$this->session->userdata('user_type');
				if(trim($user) == 'MasterDealer' or trim($user) == 'Distributor' or trim($user) == 'Agent')
				{
				$this->pageview();
				}
				else
				{redirect(base_url().'login');}																					
			}
		} 
	}
	
	

	

	





	
	
	
}