
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paytm_update extends CI_Controller {

	public function index() 
	{}
	
public function check_status()

{
    $orderid = $_REQUEST[orderid];
    $mid = $this->paytm_login("mid");
  $token = $this->paytm_login("token"); 
    $domain = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST']."/";
    $url = $domain."paytm_status.php?orderid=".$orderid."&mid=".$mid."&token=".$token;
    
    $arrContextOptions=array(
    "ssl"=>array(
        "verify_peer"=>false,
        "verify_peer_name"=>false,
    ),
);  
    
    
   $response = file_get_contents($url,false, stream_context_create($arrContextOptions));

   
   $response_r = json_decode($response,true);
   
   $status = $response_r[status];
   $msg = $response_r[message];
   
   
   
   
   
 
  $user_id = $this->get_user($orderid)->row(0)->user_id;
 $id = $this->get_user($orderid)->row(0)->id;
   $amount = $this->get_user($orderid)->row(0)->amount;
    $tid  = $this->get_user($orderid)->row(0)->txid;
   
   if($status =="Success")
   {
       $this->update_paytm_status($status,$tid); 
       
       
       $this->update_payment($user_id,$id,$amount,$tid,$msg);
       
       
       $json[status]= $status;
       $json[msg] = $msg;
       
       echo json_encode($json);
       
       exit;
   }
   
    if($status == "Failure")
   {
       $this->update_paytm_status($status,$tid); 
       
       $json[status]= $status;
       $json[msg] = $msg;
       
       echo json_encode($json);
       
       exit;
   }
   
   
     if($status == "Pending")
   {
       $this->update_paytm_status($status,$tid); 
       
       $json[status]= $status;
       $json[msg] = $msg;
       
       echo json_encode($json);
       
       exit;
   }
 

 
 
}
	
	public function paytm_order()
{
    
    $orderId = $_REQUEST[orderId];
    $status = $_REQUEST[status];
   
    $user_id = $_REQUEST[user_id];
    $amunt = $_REQUEST[amunt];
    
   $date_current = $this->common->getMySqlDate(); 
   
$db_q = "insert into paytm(txid,status,date,user_id,amount) values(?,?,?,?,?)";
$this->db->query($db_q,array($orderId,$status,$date_current,$user_id,$amunt));
}



public function get_user($orderid)
{
    $url = "select * from paytm where txid='$orderid' and status='Pending'";
  return  $stp =  $this->db->query($url);
   //return $stp->row(0)->user_id;
}

public function update_payment($user_id1,$id,$amount,$ref_no,$upi_remark)
{

			
			$bank_ref2 = $upi_remark;
    
     $user_id = $user_id1;
				$status = "Success";
				$id = $id;				
				$Amount = $amount;				
				$BankCharge = "";								
				$Remark = "Paytm Ref number |$ref_no| ".$bank_ref2;				
				$bank_id = "";
				$remark_details = "";
				if($Amount > 0)
				{
					$userinfo = $this->Userinfo_methods->getUserInfo($user_id);
					if($userinfo->num_rows() == 0)
					{
						$this->session->set_flashdata('user_message', 'User Not Exists.');	
						redirect("list_payment_request");
					}
					
					$this->load->model('Add_balance_model');	
					$payment_type = "cash";
					$transaction_type = "PAYMENT";
					$dr_user_id  = $this->Userinfo_methods->getAdminId();
					$description =  $this->Insert_model->getCreditPaymentDescription($user_id, $dr_user_id,$Amount);
					$description.='';
					$creditAmount = $Amount - $BankCharge;
					
					if($this->Common_methods->CheckBalance($dr_user_id,$creditAmount) == false)
					{
						$this->session->set_flashdata('user_message', 'You Dont Have Sufficient Balance .');	
						redirect("list_payment_request");			
							
					}
				
				
		$this->Insert_model->tblewallet_Payment_CrDrEntry($user_id,$dr_user_id,$creditAmount,$Remark,$description,$payment_type);
					
					return "success";
					
	
					
					
		

    
    
}
}


public function update_paytm_status($status,$orderid)

{
    $url = "update paytm set status='$status' where txid='$orderid'";
    
    $this->db->query($url);
    
    
}

public function paytm_login($mid)
{
    $url = "select * from pg_setting where name = 'PAYTM'";
     $rsp =  $this->db->query($url);
     
     if($mid == "mid")
     {
         return $rsp->row(0)->mid;
         
     }
      if($mid == "token")
     {
         return $rsp->row(0)->token;
         
     }
     

}

}



