<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class upi_gateway extends CI_Controller {
	
	
	private $msg='';
	public function pageview()
	{
	
		$this->view_data['message'] =$this->msg;
		$this->load->view('upi_gateway_view',$this->view_data);		
	}
	
	public function index() 
	{
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
$this->output->set_header("Pragma: no-cache"); 

		if ($this->session->userdata('logged_in') != TRUE) 
		{ 
			redirect(base_url().'login'); 
		}
	
		else 
		{ 
			$data['message']='';				
			if($this->input->post("btnSubmit") == 'Submit')
			{								
				$request_amount = $this->input->post("txtReqamt",TRUE);
						
				$user_id =$this->session->userdata("id");	
				
				if($request_amount > 50000 or $request_amount < 100 )
				
				{
				    
			$this->session->set_flashdata('message', 'Minimum 100 and maximum 50000 allowed');
					redirect(base_url()."upi_gateway");exit;
				}
							if($user_id == "1402")
		{
			$this->session->set_flashdata('message', 'Fund Request Not allowed by demo account');
					redirect(base_url()."upi_gateway");exit;
		}	
				
				
				 $gatway = $this->upi_gateway_create($request_amount,$user_id);
				 
				 
			
				 
				
	
		
		
			
	
			}			
			else
			{
				$user=$this->session->userdata('user_type');
				if(trim($user) == 'MasterDealer' or trim($user) == 'Distributor' or trim($user) == 'Agent')
				{
				$this->pageview();
				}
				else
				{redirect(base_url().'login');}																					
			}
		} 
	}
	
	
	public function upi_request($client_txn_id,$user_id,$amount,$status)
	

	{
	 
	 $date = $this->common->getMySqlDate();
	
	    $url = "insert into robotic (txid,user_id,amount,status,date) values(?,?,?,?,?)";
	    
	    $result = $this->db->query($url,array($client_txn_id,$user_id,$amount,$status,$date));
	    
	    return $result;
	}
	
	

	
	
	public function get_user($user_id)
	{
	    $url = "select * from tblusers where user_id = '$user_id'";
	 return  $user =  $this->db->query($url);
	   
	
	 

	 
	    
	    
	}

	
public function upi_gateway_create($amount,$user_id){
    
    
    $user = $this->get_user($user_id);
    
    
     $key = $this->get_upi_token();
   $client_txn_id = "RC".$this->common->getOTP().$this->common->getOTP();
  $amount = $amount;
  $p_info =  "Topup";
  $customer_name = $user->row(0)->business_name;
   $domain = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST']."/";
  $customer_email = "inf@upicompany.com";
  $customer_mobile = "9999999999";
  $user_id = $user_id;
  $redirect_url = $domain."/billing_summary";
  $status = "Pending";
  
  $this->upi_request($client_txn_id,$user_id,$amount,$status);
  

 $data = array(
    'key' => $key,
    'client_txn_id' => $client_txn_id,
    'amount' => $amount,
    'p_info' => $p_info,
    'customer_name' => $customer_name,
    'customer_email' => $customer_email,
    'customer_mobile' => $customer_mobile,
    'redirect_url' => $redirect_url
    
    );
    
    
 $payload = json_encode($data);
$url = "https://merchant.upigateway.com/api/create_order";

//$url = "https://staging.eko.in:25004/ekoapi/v2/customers/{customer_id_type}:{customer_id}";
  $u_response = $this->robo_login($url,$payload);

$u_arr = json_decode($u_response,true);

$status = $u_arr[status];
$data = $u_arr[data];

if($status == "true")
{
    
					redirect($data[payment_url]);exit;
    
    
    
   
    
}
else{
    
    $this->session->set_flashdata('message',$u_response);
					redirect(base_url()."upi_gateway");exit;
    
   echo  $u_response;
}
 
}




public function robo_login($url,$payload){
     $ch = curl_init();
     curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
    curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
    curl_setopt($ch, CURLOPT_TIMEOUT, 40000);
        curl_setopt($ch,CURLOPT_URL,$url);
         curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$payload) ;
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        ob_start();
       return $buffer = curl_exec($ch);       
        curl_close($ch);
        ob_end_clean();
    
    unset($ch);  
    
}
	



public function payment_sts()
{
     $client_txn_id = $_REQUEST['client_txn_id'];
  //$amount = $_REQUEST['amount'];
  $p_info =  "Topup";
  $customer_name = $_REQUEST['customer_name'];
  $customer_email = $_REQUEST['customer_email'];
  $customer_mobile = $_REQUEST['customer_mobile'];
  $upi_txn_id = $_REQUEST['upi_txn_id'];
   $upi_remark = $_REQUEST['remark'];
  
   
    $p_status = $_REQUEST['status'];
    
    // $date = $this->common->getMySqlDate();
    
    $url = "SELECT * FROM `robotic` WHERE `status` = 'Pending' AND `txid` = '$client_txn_id'";
    $rsl = $this->db->query($url);
   // echo json_encode($rsl);
    
     $req_sts = $rsl->row(0)->status;
   
    $user_id1 = $rsl->row(0)->user_id;
   $id = $rsl->row(0)->id;
  
   $amount = $rsl->row(0)->amount;
   
   $ref_no = $upi_txn_id;
   $utr = $ref_no;
   $response = file_get_contents("php://input");
   
   
   //https://myrc.in/ipay?ipay_id5427320id=146182&customer_vpa=&amount=500&client_txn_id=5427320&customer_name=rajesh%20kumar%20singha&customer_email=mitar1420%40gmail.com&customer_mobile=7602229229&p_info=Topup&upi_txn_id=&status=failure&remark=Transaction%20cancel%20by%20Payee&udf1=&udf2=&udf3=&redirect_url=http%3A%2F%2Fgoogle.com&txnAt=2022-04-29&createdAt=2022-04-29T00%3A48%3A51.000Z
   if($user_id1 == "")
   {
       
      exit; 
   }
   
   
   if($p_status == "success")
   
   {
       
      $status = "Success";
     $this->update_payment($user_id1,$id,$amount,$ref_no,$upi_remark); 
     $this->update_robotic_table($response,$ref_no,$status,$client_txn_id,$upi_remark);
     
     exit; 
       
   }
   elseif($p_status == "failure")
   {
       
       $status = "Failure";
      $this->update_robotic_table($response,$ref_no,$status,$client_txn_id,$upi_remark,$upi_remark);
      
      exit;
   }
    
    
}



public function update_payment($user_id1,$id,$amount,$ref_no,$upi_remark)
{

			
			$bank_ref2 = $upi_remark." Paid VIA UPI Gateway";
    
     $user_id = $user_id1;
				$status = "Success";
				$id = $id;				
				$Amount = $amount;				
				$BankCharge = "";								
				$Remark = "Bank Ref number |$ref_no| ".$bank_ref2;				
				$bank_id = "";
				$remark_details = "";
				if($Amount > 0)
				{
					$userinfo = $this->Userinfo_methods->getUserInfo($user_id);
					if($userinfo->num_rows() == 0)
					{
						$this->session->set_flashdata('user_message', 'User Not Exists.');	
						redirect("list_payment_request");
					}
					
					$this->load->model('Add_balance_model');	
					$payment_type = "cash";
					$transaction_type = "PAYMENT";
					$dr_user_id  = $this->Userinfo_methods->getAdminId();
					$description =  $this->Insert_model->getCreditPaymentDescription($user_id, $dr_user_id,$Amount);
					$description.='';
					$creditAmount = $Amount - $BankCharge;
					
					if($this->Common_methods->CheckBalance($dr_user_id,$creditAmount) == false)
					{
						$this->session->set_flashdata('user_message', 'You Dont Have Sufficient Balance .');	
						redirect("list_payment_request");			
							
					}
				
				
		$this->Insert_model->tblewallet_Payment_CrDrEntry($user_id,$dr_user_id,$creditAmount,$Remark,$description,$payment_type);
					
					return "success";
					
	
					
					
		

    
    
}
}	

public function update_robotic_table($response,$utr,$status,$client_txn_id,$upi_remark)
{
    $final_utr = $utr.$upi_remark;
    
    $qry = "update robotic set response= '$response', status ='$status', utr = '$final_utr' where txid = '$client_txn_id' ";
    $this->db->query($qry);
}
	
public function get_upi_token()
{
    $url = "select * from pg_setting where name = 'UPI'";
     $rsp =  $this->db->query($url);
   
         return $rsp->row(0)->token;
         
    
     

}	
	
}