<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pg_setting extends CI_Controller {
	
	
	private $msg='';
	public function pageview()
	{
		if ($this->session->userdata('alogged_in') != TRUE) 
		{ 
			redirect(base_url().'login'); 
		} 
		$start_row = $this->uri->segment(3);
		$per_page = $this->common_value->getPerPage();
		if(trim($start_row) == ""){$start_row = 0;}
		
		$this->view_data['result_upi'] = $this->get_upi();
		$this->view_data['result_api'] = $this->get_paytm();
		$this->view_data['message'] =$this->msg;
		$this->load->view('pg_setting_view',$this->view_data);		
	}
	
	public function index() 
	{
				$this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
$this->output->set_header("Pragma: no-cache"); 

		if ($this->session->userdata('alogged_in') != TRUE) 
		{ 
			redirect(base_url().'login'); 
		} 
		else 
		{ 
			$data['message']='';				
			if($this->input->post("btnSubmit") == "Submit")
			{
				$ApiName = $this->input->post("txtAPIName",TRUE);
				$url = $this->input->post("url",TRUE);
				$response_type = $this->input->post("response_type",TRUE);
				$status_response_text = $this->input->post("status_response_text",TRUE);
				$txid_response_text = $this->input->post("txid_response_text",TRUE);
				$opid_response_text = $this->input->post("opid_response_text",TRUE);
				$success_response_text = $this->input->post("success_response_text",TRUE);
				$failure_response_text = $this->input->post("failure_response_text",TRUE);
				$message_response_text = $this->input->post("message_response_text",TRUE);
				$ipaddress = $this->input->post("ipaddress",TRUE);
				$method = $this->input->post("method",TRUE);
				
			
				if($this->add($ApiName,$url,$response_type,$status_response_text,$txid_response_text,$opid_response_text,$success_response_text,$failure_response_text,$message_response_text,$ipaddress,$method) == true)
				{
					$this->msg ="Api Add Successfully.";
					$this->pageview();
				}
				else
				{
					
				}
			}
			else if($this->input->post("btnSubmit") == "paytm")
			{				
				
				$mid = $this->input->post("mid",TRUE); 
				$key = $this->input->post("key",TRUE); 
				$web_status = $this->input->post("web_status",TRUE); 
				$app_status = $this->input->post("app_status",TRUE); 
					
			
				if($this->update_paytm($mid,$key,$web_status,$app_status) == true)
				{
					$this->msg ="Updated Successfully.";
					$this->pageview();
				}
				else
				{
					
				}				
			}
			
			
				else if($this->input->post("btnSubmit") == "upi")
			{				
				
				
				$key = $this->input->post("key",TRUE); 
				$web_status = $this->input->post("web_status",TRUE); 
				$app_status = $this->input->post("app_status",TRUE); 
					
			
				if($this->update_upi($key,$web_status,$app_status) == true)
				{
					$this->msg ="Updated Successfully.";
					$this->pageview();
				}
				else
				{
					
				}				
			}
			
			
			else if( $this->input->post("hidValue") && $this->input->post("action") ) 
			{				
				$apiID = $this->input->post("hidValue",TRUE);
				$this->load->model('Api_model');
				if($this->delete($apiID) == true)
				{
					$this->msg ="Api Delete Successfully.";
					$this->pageview();
				}
				else
				{
					
				}				
			}
			else
			{
				$user=$this->session->userdata('auser_type');
				if(trim($user) == 'Admin')
				{
				$this->pageview();
				}
				else
				{redirect(base_url().'login');}																					
			}
		} 
	}	
	
	
	
	
	
		public	function add($ApiName,$url,$response_type,$status_response_text,$txid_response_text,$opid_response_text,$success_response_text,$failure_response_text,$message_response_text,$ipaddress,$method)
	{
		$this->load->library('common');
		$ip = $this->common->getRealIpAddr();
		$date = $this->common->getDate();
		$str_query = "insert into tblapi(api_name,url,response_type,status_response_text,txid_response_text,opid_response_text,success_response_text,failure_response_text,message_response_text,ipaddress,method) values(?,?,?,?,?,?,?,?,?,?,?)";
		$result = $this->db->query($str_query,array($ApiName,$url,$response_type,$status_response_text,$txid_response_text,$opid_response_text,$success_response_text,$failure_response_text,$message_response_text,$ipaddress,$method));		
		if($result > 0)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}	
	public	function delete($apiID)
	{	
		$str_query = "delete from tblapi where api_id=?";
		$result = $this->db->query($str_query,array($apiID));		
		if($result > 0)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}	
	
	public	function update_paytm($mid,$key,$web_status,$app_status)
	{	
		$str_query = "update pg_setting set mid ='$mid', token = '$key' , web_status = '$web_status' , app_status = '$app_status' where name='PAYTM'";
		$result = $this->db->query($str_query);		
		if($result > 0)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}	
	
		public	function update_upi($key,$web_status,$app_status)
	{	
		$str_query = "update pg_setting set token = '$key' , web_status = '$web_status' , app_status = '$app_status' where name='UPI'";
		$result = $this->db->query($str_query);		
		if($result > 0)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
	
	

	public function get_paytm()
	{
		$str_query = "select * from  pg_setting where  name ='PAYTM' ";
		$result = $this->db->query($str_query);
		return $result;
	}	
	
	public function get_upi()
	{
		$str_query = "select * from  pg_setting where  name ='UPI' ";
		$result = $this->db->query($str_query);
		return $result;
	}	
	
	
	
}